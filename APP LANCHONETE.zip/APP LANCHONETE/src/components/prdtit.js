// ProductItem.js

import React, { useState } from 'react';
import { Image, Text, View } from 'react-native';

export default function ProductItem({ product }) {

  const [isFavorite, setIsFavorite] = useState(false);

  return (
    <View>
      <Image source={{ uri: product.image }} />
      <Text>{product.name}</Text>
      <Text>{product.price}</Text>
      <Button
        title="Add to favorites"
        onPress={() => setIsFavorite(!isFavorite)}
      />
    </View>
  );

}
