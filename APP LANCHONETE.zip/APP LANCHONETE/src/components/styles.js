import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  appBar: {
    backgroundColor: '#fff',
  },
  appBarTitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  productItem: {
    margin: 10,
  },
  productImage: {
    width: 100,
    height: 100,
  },
  productName: {
    fontSize: 16,
  },
  productPrice: {
    fontSize: 14,
    color: '#999',
  },
});

export default styles;
