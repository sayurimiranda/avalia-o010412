// AppBar.js

import React from 'react';
import { Appbar } from 'react-native-paper';

export default function AppBar({ title }) {

  return (
    <Appbar>
      <Appbar.Content title={title} />
    </Appbar>
  );

}
