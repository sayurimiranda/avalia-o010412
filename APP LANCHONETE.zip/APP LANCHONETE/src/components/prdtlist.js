// ProductList.js

import React, { useState } from 'react';
import { FlatList } from 'react-native';
import ProductItem from './ProductItem';

export default function ProductList({ data }) {

  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setIsLoading(true);
    fetch('https://api.example.com/products')
      .then((response) => response.json())
      .then((products) => {
        setIsLoading(false);
        setProducts(products);
      });
  }, []);

  return (
    <FlatList
      data={data}
      keyExtractor={(item) => item.id}
      renderItem={({ item }) => (
        <ProductItem product={item} />
      )}
    />
  );

}
