import React from 'react';
import { View } from 'react-native';

import ProductsScreen from './screens/ProductsScreen';

export default function App() {

  return (
    <View>
      <ProductsScreen />
    </View>
  );

}
