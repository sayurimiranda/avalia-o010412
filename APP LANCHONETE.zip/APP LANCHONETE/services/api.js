// api.js

export async function getProducts() {

    const response = await fetch('https://api.example.com/products');
    return response.json();
  
  }
  