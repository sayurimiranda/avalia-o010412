// ProductsScreen.js

import React, { useEffect, useState } from 'react';
import { View } from 'react-native';

import AppBar from '../components/AppBar';
import ProductList from '../components/ProductList';
import { getProducts } from '../services/api';

export default function ProductsScreen() {

  const [products, setProducts] = useState([]);

  useEffect(() => {
    getProducts().then(setProducts);
  }, []);

  return (
    <View>
      <AppBar title="Products" />
      <ProductList data={products} />
    </View>
  );

}
